var pash = new Pash({
  caretInterval: 500
});
var pashAutoComplete = new PashAutoComplete(pash);
var pashHistory = new WshHistory(pash);
