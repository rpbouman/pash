pash
====

Pentaho Analysis Shell
